package uebung1

case class Failure(exception: Any) {

}
