package uebung1

case class Success(value: Any) {

}
